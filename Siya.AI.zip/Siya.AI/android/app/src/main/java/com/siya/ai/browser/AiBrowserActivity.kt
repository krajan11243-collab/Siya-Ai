package com.siya.ai.browser

import android.app.Activity
import android.graphics.Color
import android.os.Bundle
import android.view.Gravity
import android.view.ViewGroup
import android.view.WindowManager
import android.view.inputmethod.EditorInfo
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView

/** AI Browser ka poori screen wala roop. App se bahar jaane par browser chhoti floating window ban kar piche chalta hai. */
class AiBrowserActivity : Activity() {
    private lateinit var host: FrameLayout

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        val d = resources.displayMetrics.density

        fun btn(label: String, onClick: () -> Unit) = TextView(this).apply {
            text = label; setTextColor(0xFF3EE6FF.toInt()); textSize = 20f; gravity = Gravity.CENTER
            setPadding((14 * d).toInt(), (8 * d).toInt(), (14 * d).toInt(), (8 * d).toInt())
            setOnClickListener { onClick() }
        }
        val url = EditText(this).apply {
            setTextColor(Color.WHITE); setHintTextColor(0x88FFFFFF.toInt()); hint = "Google par search ya website"
            textSize = 14f; maxLines = 1; setSingleLine(true); imeOptions = EditorInfo.IME_ACTION_GO
            setBackgroundColor(0xFF0B2236.toInt()); setPadding((12 * d).toInt(), 0, (12 * d).toInt(), 0)
            setOnEditorActionListener { v, _, _ -> AiBrowser.open(this@AiBrowserActivity, v.text.toString(), "full"); true }
        }
        val bar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
            setBackgroundColor(0xFF071826.toInt())
            addView(btn("\u2190") { AiBrowser.back(this@AiBrowserActivity) })
            addView(url, LinearLayout.LayoutParams(0, (40 * d).toInt(), 1f))
            addView(btn("\u2750") { AiBrowser.windowControl(this@AiBrowserActivity, "popup") })   // chhoti window
            addView(btn("\u22EE") { AiBrowser.toggleMenu(this@AiBrowserActivity) })              // 3-dot menu
            addView(btn("\u2715") { AiBrowser.close(this@AiBrowserActivity) })
        }
        host = FrameLayout(this).apply { setBackgroundColor(0xFF020A14.toInt()) }
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setBackgroundColor(0xFF020A14.toInt())
            fitsSystemWindows = true
            addView(bar, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
            addView(host, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
        }
        setContentView(root)
    }

    override fun onStart() {
        super.onStart()
        AiBrowser.activity = this
        AiBrowser.attachTo(host)
    }

    override fun onStop() {
        // app se bahar: browser floating window ban kar chalta rahe (gaana / video na ruke)
        if (!isFinishing && !isChangingConfigurations) {
            AiBrowser.detachFrom(host)
            if (AiBrowser.activity === this) AiBrowser.activity = null
            AiBrowser.sendToBackground(this)
        }
        super.onStop()
    }

    override fun onDestroy() {
        AiBrowser.detachFrom(host)
        if (AiBrowser.activity === this) AiBrowser.activity = null
        super.onDestroy()
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        if (!AiBrowser.back(this).startsWith("OK")) super.onBackPressed()
    }
}
