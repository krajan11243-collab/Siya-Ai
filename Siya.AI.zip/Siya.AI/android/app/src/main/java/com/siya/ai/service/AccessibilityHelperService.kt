package com.siya.ai.service

import android.accessibilityservice.AccessibilityService
import android.content.Context
import android.provider.Settings
import android.view.accessibility.AccessibilityEvent

class AccessibilityHelperService : AccessibilityService() {

    companion object {
        var instance: AccessibilityHelperService? = null
            private set

        // Ye check karta hai ki kya user ne Accessibility permission on ki hai
        fun isEnabled(context: Context): Boolean {
            var accessibilityEnabled = 0
            val service = "${context.packageName}/${AccessibilityHelperService::class.java.canonicalName}"
            try {
                accessibilityEnabled = Settings.Secure.getInt(
                    context.applicationContext.contentResolver,
                    Settings.Secure.ACCESSIBILITY_ENABLED
                )
            } catch (e: Settings.SettingNotFoundException) {
                e.printStackTrace()
            }
            if (accessibilityEnabled == 1) {
                val settingValue = Settings.Secure.getString(
                    context.applicationContext.contentResolver,
                    Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES
                )
                if (settingValue != null) {
                    return settingValue.contains(service)
                }
            }
            return false
        }
    }

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        // Screen par hone wale changes ko yahan se monitor kiya jayega
    }

    override fun onInterrupt() {
        // Service interrupt hone par handle karna
    }

    override fun onDestroy() {
        super.onDestroy()
        instance = null
    }
}
