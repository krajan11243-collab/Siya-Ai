package com.siya.ai.service

import android.service.notification.NotificationListenerService

/**
 * Khaali listener: iska kaam sirf itna hai ki Android Siya ko "Notification access" de de,
 * jisse Siya dekh sake ki abhi kaun sa gaana / video chal raha hai (MediaSession) aur use pause / next kar sake.
 * Notifications ka content Siya padhti nahi.
 */
class SiyaNotificationListener : NotificationListenerService()
