package com.siya.ai.service

import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Canvas
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.RadialGradient
import android.graphics.RectF
import android.graphics.Shader
import android.view.MotionEvent
import android.view.View
import kotlin.math.PI
import kotlin.math.sin

class OrbOverlayView(context: Context, private val onTap: () -> Unit) : View(context) {
    private val d = resources.displayMetrics.density
    private val bg = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xE9071020.toInt() }
    private val stroke = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeWidth = 1.4f*d; color = 0xAA35E8FF.toInt() }
    private val orb = Paint(Paint.ANTI_ALIAS_FLAG)
    private val ring = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeWidth = 2.2f*d }
    private val text = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xFFFFFFFF.toInt(); textSize = 15f*d; isFakeBoldText = true }
    private val sub = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xB8C8F5FF.toInt(); textSize = 10.5f*d }
    private val rect = RectF()
    private var t=0f
    private var level=0.12f
    private var label="Siya"
    private var stateName="waiting"

    private val anim = ValueAnimator.ofFloat(0f,1f).apply {
        duration=1300; repeatCount=ValueAnimator.INFINITE
        addUpdateListener { t=it.animatedValue as Float; invalidate() }
    }

    fun update(event: Map<String,Any?>) {
        when(event["type"]) {
            "state" -> {
                stateName=event["state"] as? String ?: "idle"
                label=when(stateName) {
                    "listening" -> "Siya sun rahi hai"
                    "speaking" -> "Siya bol rahi hai"
                    "processing","thinking" -> "Siya soch rahi hai"
                    else -> "Siya"
                }
                invalidate()
            }
            "amp" -> { level=((event["v"] as? Double) ?: 0.0).toFloat().coerceIn(0f,1f); invalidate() }
        }
    }

    override fun onAttachedToWindow(){super.onAttachedToWindow();anim.start()}
    override fun onDetachedFromWindow(){anim.cancel();super.onDetachedFromWindow()}
    override fun onMeasure(w:Int,h:Int)=setMeasuredDimension((292*d).toInt(),(104*d).toInt())

    override fun onDraw(c:Canvas) {
        rect.set(2*d,2*d,width-2*d,height-2*d)
        c.drawRoundRect(rect,52*d,52*d,bg)
        c.drawRoundRect(rect,52*d,52*d,stroke)
        val cx=58*d
        val cy=height/2f
        val pulse=0.5f+0.5f*sin(t*2*PI).toFloat()
        val r=(24+8*level+3*pulse)*d
        c.drawCircle(cx,cy,r*2.6f,Paint(Paint.ANTI_ALIAS_FLAG).apply {
            shader=RadialGradient(cx,cy,r*2.6f,intArrayOf(0x664DEBFF.toInt(),0x443B82F6.toInt(),0x337C3AED.toInt(),0x00FF4FD8.toInt()),floatArrayOf(0f,.38f,.72f,1f),Shader.TileMode.CLAMP)
        })
        orb.shader=RadialGradient(cx-r*.35f,cy-r*.35f,r*1.45f,intArrayOf(0xFFB8FFFF.toInt(),0xFF35E8FF.toInt(),0xFF3B82F6.toInt(),0xFF8B5CF6.toInt(),0xFFFF4FD8.toInt()),floatArrayOf(0f,.28f,.55f,.8f,1f),Shader.TileMode.CLAMP)
        c.drawCircle(cx,cy,r,orb)
        ring.shader=LinearGradient(cx-r,cy-r,cx+r,cy+r,intArrayOf(0xFF35E8FF.toInt(),0xFF8B5CF6.toInt(),0xFFFF4FD8.toInt()),null,Shader.TileMode.CLAMP)
        ring.alpha=(150+90*(1-pulse)).toInt()
        c.drawCircle(cx,cy,r+(7+8*level)*d*(.65f+.35f*pulse),ring)
        c.drawText(label,102*d,cy+2*d,text)
        c.drawText("VOICE • ACTIVE",102*d,cy+20*d,sub)
    }

    override fun onTouchEvent(e:MotionEvent):Boolean {
        if(e.action==MotionEvent.ACTION_UP){onTap();performClick()}
        return true
    }
    override fun performClick():Boolean{super.performClick();return true}
}
