"Hey Siya" offline wake word (Picovoice Porcupine)
1. https://console.picovoice.ai par free account banao, AccessKey copy karo.
2. Porcupine > "Hey Siya" (English) train karo > Platform: Android > Download.
3. Download hui .ppn file ka naam hey_siya.ppn rakho aur isi folder (android/app/src/main/assets/) mein daalo.
4. App mein Settings > Features > Picovoice AccessKey mein key paste karo, "Hello Siya (hamesha on)" ON karo.
.ppn ya key na ho to app purane speech-recognizer wale wake word par chalta hai.
