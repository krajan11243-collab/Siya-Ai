import 'package:flutter/material.dart';

/// Ek jagah saare colors - design image se match.
class SiyaColors {
  static const Color bg = Color(0xFF020A14);
  static const Color card = Color(0xFF0A1826);
  static const Color cyan = Color(0xFF22D3EE);
  static const Color cyanSoft = Color(0xFF3EE6FF);
  static const Color blue = Color(0xFF2F6BFF);
  static const Color purple = Color(0xFF8B5CF6);
  static const Color violet = Color(0xFFB07CFF);
  static const Color ok = Color(0xFF00E676);
  static const Color warn = Color(0xFFFFA726);
  static const Color bad = Color(0xFFFF5252);
}

/// Home screen par status text dikhana hai ya nahi.
/// Design mein wo text hata diya gaya hai, isliye default false.
const bool kShowStatusText = false;
