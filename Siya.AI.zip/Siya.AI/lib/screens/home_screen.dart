import 'dart:math' as math;

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import '../bridge/siya_bridge.dart';
import '../theme.dart';
import '../widgets/mic_button.dart';
import '../widgets/orb_painter.dart';
import '../widgets/siya_title.dart';
import '../widgets/wallpaper_layer.dart';
import '../widgets/wave_painter.dart';
import 'settings_screen.dart';

/// Main screen - image wale design ka 100% match.
/// Layout screen ki width/height ke ratio se bana hai, isliye har phone par same dikhta hai.
class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key, required this.bridge});

  final SiyaBridge bridge;

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> with TickerProviderStateMixin {
  late final AnimationController _ctrl;
  late final AnimationController _intro;
  final ValueNotifier<double> _level = ValueNotifier<double>(0.15);

  // wallpaper (Settings > Wallpaper)
  String _wpType = 'none';
  String _wpPath = '';
  bool _wpSound = false;
  double _wpDim = 0.35;

  Future<void> _loadWallpaper() async {
    try {
      final s = await widget.bridge.getSettings();
      if (!mounted) return;
      setState(() {
        _wpType = (s['wallpaper_type'] as String?) ?? 'none';
        _wpPath = (s['wallpaper_path'] as String?) ?? '';
        _wpSound = (s['wallpaper_sound'] as bool?) ?? false;
        _wpDim = ((s['wallpaper_dim'] as num?) ?? 0.35).toDouble();
      });
    } catch (_) {}
  }

  Animation<double> _iv(double a, double b, Curve c) =>
      CurvedAnimation(parent: _intro, curve: Interval(a, b, curve: c));

  @override
  void initState() {
    super.initState();
    _ctrl = AnimationController(vsync: this, duration: const Duration(seconds: 16))..repeat();
    _ctrl.addListener(_tick);
    // Open animation: turant shuru (kisi cheez ka intezaar nahi)
    _intro = AnimationController(vsync: this, duration: const Duration(milliseconds: 1400))..forward();
    widget.bridge.listen();
    widget.bridge.error.addListener(_onError);
    WidgetsBinding.instance.addPostFrameCallback((_) async {
      await widget.bridge.init();
      _loadWallpaper();
      if (await widget.bridge.consumeFirstRun()) {
        await Future<void>.delayed(const Duration(milliseconds: 900));
        await widget.bridge.requestPermissions(); // notification + mic + baaki
      }
    });
  }

  void _onError() {
    final code = widget.bridge.error.value;
    if (code == null || !mounted) return;
    widget.bridge.error.value = null;
    final msg = switch (code) {
      'no_key' => 'Settings mein Gemini API Key daalo',
      'no_mic' => 'Mic permission chahiye',
      'connection' => 'Connection nahi ho paya. Internet / API key check karo',
      _ => 'Kuch gadbad hui, dobara try karo',
    };
    ScaffoldMessenger.of(context)
      ..hideCurrentSnackBar()
      ..showSnackBar(SnackBar(
        content: Text(msg),
        behavior: SnackBarBehavior.floating,
        backgroundColor: const Color(0xFF0B2236),
        action: code == 'no_key'
            ? SnackBarAction(label: 'Settings', textColor: SiyaColors.cyanSoft, onPressed: _openSettings)
            : null,
      ));
  }

  void _tick() {
    final b = widget.bridge;
    double target;
    switch (b.state) {
      case 'listening':
        target = 0.45 + 0.55 * b.amp.value;
        break;
      case 'speaking':
        target = 0.72 + 0.28 * math.sin(_ctrl.value * math.pi * 2 * 24).abs();
        break;
      case 'processing':
      case 'waiting':
        target = 0.6;
        break;
      default:
        target = 0.15;
    }
    _level.value += (target - _level.value) * 0.1;
  }

  @override
  void dispose() {
    widget.bridge.error.removeListener(_onError);
    _ctrl.removeListener(_tick);
    _ctrl.dispose();
    _intro.dispose();
    _level.dispose();
    super.dispose();
  }

  Future<void> _openSettings() async {
    await Navigator.of(context).push(
      MaterialPageRoute<void>(builder: (_) => SettingsScreen(bridge: widget.bridge)),
    );
    _loadWallpaper(); // wallpaper badli ho to turant dikhe
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: SiyaColors.bg,
      body: LayoutBuilder(builder: (context, c) {
        final w = c.maxWidth;
        final h = c.maxHeight;
        final orb = w * 0.96;
        final micSlot = w * 0.22;
        final waveW = (w * 0.96 - micSlot) / 2;
        final waveH = w * 0.20;

        return Stack(
          children: [
            // background
            const Positioned.fill(
              child: DecoratedBox(
                decoration: BoxDecoration(
                  gradient: RadialGradient(
                    center: Alignment(0, -0.22),
                    radius: 1.05,
                    colors: [Color(0xFF07203A), Color(0xFF031019), Color(0xFF01050B)],
                    stops: [0.0, 0.55, 1.0],
                  ),
                ),
              ),
            ),

            // wallpaper (photo / video) - hologram ke peeche
            Positioned.fill(
              child: WallpaperLayer(type: _wpType, path: _wpPath, sound: _wpSound, dim: _wpDim),
            ),

            // title
            Positioned(
              top: h * 0.071 - w * 0.10,
              left: 0,
              right: 0,
              child: FadeTransition(
                opacity: _iv(0.05, 0.55, Curves.easeOut),
                child: SlideTransition(
                  position: Tween<Offset>(begin: const Offset(0, -0.5), end: Offset.zero)
                      .animate(_iv(0.05, 0.6, Curves.easeOutCubic)),
                  child: Center(child: SiyaTitle(width: w)),
                ),
              ),
            ),

            // settings button
            Positioned(
              top: h * 0.0595 - w * 0.05,
              right: w * 0.036,
              child: FadeTransition(
                opacity: _iv(0.25, 0.7, Curves.easeOut),
                child: _SettingsButton(size: w * 0.10, onTap: _openSettings),
              ),
            ),

            // orb
            Positioned(
              left: (w - orb) / 2,
              top: h * 0.401 - orb / 2,
              width: orb,
              height: orb,
              child: FadeTransition(
                opacity: _iv(0.0, 0.6, Curves.easeOut),
                child: ScaleTransition(
                  scale: Tween<double>(begin: 0.55, end: 1).animate(_iv(0.0, 0.85, Curves.easeOutBack)),
                  child: RepaintBoundary(
                    child: CustomPaint(painter: OrbPainter(time: _ctrl, level: _level)),
                  ),
                ),
              ),
            ),

            // optional status text (design mein off)
            if (kShowStatusText)
              Positioned(
                top: h * 0.672,
                left: w * 0.1,
                right: w * 0.1,
                child: AnimatedBuilder(
                  animation: widget.bridge,
                  builder: (_, __) => Text(
                    widget.bridge.status,
                    textAlign: TextAlign.center,
                    style: TextStyle(
                      color: Colors.white,
                      fontSize: w * 0.05,
                      height: 1.35,
                    ),
                  ),
                ),
              ),

            // waveform + mic
            Positioned(
              left: w * 0.02,
              right: w * 0.02,
              top: h * 0.832 - micSlot / 2,
              height: micSlot,
              child: FadeTransition(
                opacity: _iv(0.35, 0.85, Curves.easeOut),
                child: SlideTransition(
                  position: Tween<Offset>(begin: const Offset(0, 0.7), end: Offset.zero)
                      .animate(_iv(0.35, 1.0, Curves.easeOutCubic)),
                  child: Row(
                children: [
                  SizedBox(
                    width: waveW,
                    height: micSlot,
                    child: Center(
                      child: SizedBox(
                        width: waveW,
                        height: waveH,
                        child: RepaintBoundary(
                          child: CustomPaint(
                            painter: WavePainter(time: _ctrl, level: _level, leftSide: true),
                          ),
                        ),
                      ),
                    ),
                  ),
                  AnimatedBuilder(
                    animation: widget.bridge,
                    builder: (_, __) => MicButton(
                      size: micSlot,
                      time: _ctrl,
                      level: _level,
                      state: widget.bridge.state,
                      onTap: () {
                        HapticFeedback.lightImpact();
                        widget.bridge.toggleMic();
                      },
                    ),
                  ),
                  SizedBox(
                    width: waveW,
                    height: micSlot,
                    child: Center(
                      child: SizedBox(
                        width: waveW,
                        height: waveH,
                        child: RepaintBoundary(
                          child: CustomPaint(
                            painter: WavePainter(time: _ctrl, level: _level, leftSide: false),
                          ),
                        ),
                      ),
                    ),
                  ),
                ],
              ),
                ),
              ),
            ),
          ],
        );
      }),
    );
  }
}

class _SettingsButton extends StatelessWidget {
  const _SettingsButton({required this.size, required this.onTap});

  final double size;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        width: size,
        height: size,
        decoration: BoxDecoration(
          color: const Color(0xFF071826),
          borderRadius: BorderRadius.circular(size * 0.26),
          border: Border.all(color: SiyaColors.cyan.withOpacity(0.75), width: 1.4),
          boxShadow: [
            BoxShadow(color: SiyaColors.cyan.withOpacity(0.28), blurRadius: 12),
          ],
        ),
        child: Icon(Icons.settings_outlined, color: Colors.white, size: size * 0.56),
      ),
    );
  }
}
